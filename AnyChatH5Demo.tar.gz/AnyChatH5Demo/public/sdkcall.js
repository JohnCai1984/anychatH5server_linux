var system_type = getsystem();
var usermediainfo = [];
var errorCode = BRAC_InitSDK(1);
if (errorCode == GV_ERR_BROWSERNOWEBRTC) {
    console.error("不支持webRTC");
}

BRAC_SetSDKOption(BRAC_SO_ENABLEWEBSERVICE, 1); //打开内部web容器
var user_open_id = 0;  
//document.getElementById('sigserverurl').value = 'http://demo.anychat.cn:8930';
//document.getElementById('uploadServerUrl').value = 'https://demo.anychat.cn/h5upload/record';
document.getElementById('username').value = 'AnyChat_H5';
// document.getElementById('userid').value = localStorage.anychat_userid || '';
document.getElementById('roomid').value = Math.round(Math.random()*1000);
document.getElementById('appid').value = localStorage.appid || '';
document.getElementById('ip0').value = 'h5service.anychat.net.cn';
document.getElementById('port0').value = '9940'; 

var isShowStreamRate = false;

function getsystem (type) {
    if (navigator) {
        var userAgentInfo = navigator.userAgent;
    } else {
        if (type === 1) return 3;
        return 'ios';
    }
    if (userAgentInfo.indexOf('Chrome/60.0.3112.116') > 0) {
        //特殊浏览器版本，宽高比和高宽比反了
        gateway.mobile_type = 1;
    }
    var android = new Array("Android");
    var ios = new Array("iPhone", "iPad", "iPod", "Safari");
    var windows = new Array("Windows",'Linux');
    for (var v = 0; v < android.length; v++) {
        var k = userAgentInfo.indexOf(android[v]);
        if (k > 0) {
            if (type === 1) return 2;
            return 'android';
        }
    }
    for (var v = 0; v < windows.length; v++) {
        var k = userAgentInfo.indexOf(windows[v]);
        if (k > 0) {
            if (type === 1) return 1;
            return 'windows';
        }
    }
    for (var v = 0; v < ios.length; v++) {
        var k = userAgentInfo.indexOf(ios[v]);
        if (k > 0) {
            if (type === 1) {
                if (userAgentInfo.indexOf("iPhone") > 0) {
                    log('iphone');
                    return 4;
                }
                return 3;
            } else {

            }
            return 'ios';
        }
    }
};

function setServerAuthPass()
{
    var authPass = document.getElementById('serverAuthPass').value || '';
    if(authPass == '')
    {
        alert('server auth pass is invalid!');
    }
    else
    {
        BRAC_SetServerAuthPass(authPass);
    }
}

function connect() {
    //BRAC_SetSDKOption(BRAC_SO_H5WEBSDK_VERSION, 2); //设置适配版本
    var ip = getPar('ip0') || document.getElementById('ip0').value || '127.0.0.1';
    localStorage.anychat_ip = ip;
    var port = getPar('port0') || document.getElementById('port0').value || '8940';
    localStorage.port = port;
    BRAC_Connect(ip, port);
    //BRAC_Connect("h5yy.anychat.net.cn", 7780);
    //BRAC_Connect("demo.anychat.cn", 7940);
    //BRAC_Connect("gw.anychat.net.cn", 8940);
    //BRAC_Connect("demo.anychat.cn", 5940);
    //BRAC_Connect("demo.anychat.cn", 8940);
    //BRAC_Connect("demo.anychat.cn", 10110);
    //BRAC_Connect("demo.anychat.cn", 3940);
    //BRAC_Connect("demo.anychat.cn", 9990);
    //BRAC_Connect("gw.anychat.net.cn", 9940);
    //BRAC_Connect("demo.anychat.cn", 10040);
}

var photographCanvas = document.getElementById('photograph');

function emptyLog(){
    document.querySelector("#log").innerHTML = "";
}

//demo 录像方法
var record_status = 1;
function play_a() {
    var record_index = $('#display_model').val();
    switch (record_index) {
        case "0":
            BRAC_SetSDKOption(BRAC_SO_RECORD_CLIPMODE, ANYCHAT_VIDEOCLIPMODE_AUTO);
            break;
        case "1":
            BRAC_SetSDKOption(BRAC_SO_RECORD_CLIPMODE, ANYCHAT_VIDEOCLIPMODE_OVERLAP);
            break;
        case "2":
            BRAC_SetSDKOption(BRAC_SO_RECORD_CLIPMODE, ANYCHAT_VIDEOCLIPMODE_SHRINK);
            break;
        case "3":
            BRAC_SetSDKOption(BRAC_SO_RECORD_CLIPMODE, ANYCHAT_VIDEOCLIPMODE_STRETCH);
            break;
        case "4":
            BRAC_SetSDKOption(BRAC_SO_RECORD_CLIPMODE, ANYCHAT_VIDEOCLIPMODE_DYNAMIC);
            break;
        default:
            BRAC_SetSDKOption(BRAC_SO_RECORD_CLIPMODE, ANYCHAT_VIDEOCLIPMODE_AUTO);
            break;
    }

    var rec_tag = BRAC_RECORD_FLAGS_SERVER + BRAC_RECORD_FLAGS_VIDEO + BRAC_RECORD_FLAGS_AUDIO + BRAC_RECORD_FLAGS_MIXAUDIO + BRAC_RECORD_FLAGS_MIXVIDEO + BRAC_RECORD_FLAGS_STEREO + BRAC_RECORD_FLAGS_LOCALCB;
    var record_index = $('#record_model').val();
    if ("1" == record_index) 
    {
        rec_tag += BRAC_RECORD_FLAGS_ABREAST;
    }
    
    BRAC_StreamRecordCtrlEx(-1, record_status, rec_tag, 0, "");
    var errorcode = 0;
    if (errorcode == 0) {
        if (record_status == 1) {
            $('#re').text('结束录像');
            record_status = 0;

        } else {
            record_status = 1;
            $('#re').text('开始录像');
        }
    }
}

//拍照
function take_a_picture() {
    var userid = GetSelectOptionValue('select_shot_uid');
    if (userid == '' || !userid) 
    {
        userid = -1;
    }
    BRAC_SnapShot(userid, 0, 0);
    //BRAC_StreamRecordCtrlEx(userid, 1, BRAC_RECORD_FLAGS_SNAPSHOT, 0, '');
}

function take_server_picture()
{
    var userid = GetSelectOptionValue('select_shot_uid');
    var rec_tag = BRAC_RECORD_FLAGS_SERVER + BRAC_RECORD_FLAGS_SNAPSHOT;
    BRAC_StreamRecordCtrlEx(userid, 1,  rec_tag, 0, '');
}

var local_record_status = 1;
var record_url = '';
var record_video_id = "play_record_video";
var record_video_class = "play_record_video";
var record_video_name = "play_record_video";
function take_local_record() 
{
    document.getElementById("playLcoalRecord").setAttribute("disabled", true);
    var userid = -1;
    var rec_tag = BRAC_RECORD_FLAGS_VIDEO + BRAC_RECORD_FLAGS_AUDIO;
    BRAC_StreamRecordCtrlEx(userid, local_record_status,  rec_tag, 0, '');
    if (local_record_status == 1) {
        $('#localrecord').text('结束本地录像');
        local_record_status = 0;

    } else {
        local_record_status = 1;
        $('#localrecord').text('开始本地录像');
    }    
}

function show_local_record(recordUrl)
{
    record_url = recordUrl;
}

function play_local_record()
{
    if(record_url == "" || record_url == null)
    {
        alert('record is not exist!');
        return;
    }
    log("play record: " + record_url);
    CreateVideoTagTest(record_video_id, record_video_class, record_video_name, record_url);
    //var video = document.getElementById("record_video_id");
}

function download_record() 
{
    if(record_url == "" || record_url == null)
    {
        alert('record is not exist!');
        return;
    }

    var save_link = document.createElementNS('http://www.w3.org/1999/xhtml', 'a');
    save_link.href = record_url;
    save_link.download = "test.webm";
    save_link.click();
    var event = document.createEvent('MouseEvents');
    event.initMouseEvent('click', true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
    save_link.dispatchEvent(event);
}

function upload_record()
{
    var formData = BRAC_GetSDKOptionStringEx(BRAC_SO_H5WEBSDK_BLOBDATA, record_url, 0);
    if(null == formData)
    {
        log('video data is Changing, please try it late!');
        return;
    }

    var server_url = "/h5upload/record";
    //server_url = "http://127.0.0.1:8993";

    //var request = new XMLHttpRequest();
    //request.open("POST", server_url);
    //request.send(formData);

    $.ajax({
        url: server_url,
        method: 'POST',
        cache:false,
        processData: false,
        contentType: false,
        data: formData,
        success: function(res)
        {
            log('录像上传成功! res:' + res);
            if(res.status && res.status == 200)
            {
                var recordUrl = res.responseText;
                //recordUrl = "https://vip.anychat.cn/mp4/2019.mp4";
                record_url = recordUrl;
                document.getElementById("playLcoalRecord").removeAttribute("disabled");
                log("retrecord: " + recordUrl);
            }
        },
        error: function(res)
        {
            if(res.status && res.status == 200)
            {
                var recordUrl = res.responseText;
                record_url = recordUrl;
                document.getElementById("playLcoalRecord").removeAttribute("disabled");
                log("retrecord: " + recordUrl);
            }
            else
            {
                log('录像上传失败!');
            }
        }
    })
}

function CreateVideoTagTest(id, classname, name, record_url)
{
    var videos = document.getElementById('play_local_record');    
    var newVideo = document.createElement("video");
    newVideo.setAttribute("autoplay", "");
    newVideo.setAttribute("id", id);
    newVideo.setAttribute("class", classname);
    newVideo.setAttribute('name', name);
    newVideo.setAttribute('src', record_url);
    newVideo.setAttribute('playsinline', "true");
    //newVideo.setAttribute('x5-playsinline', "true");
    //newVideo.setAttribute('x5-video-player-type', "h5");
    //newVideo.setAttribute('webkit-playsinline', "true");
    //newVideo.setAttribute('preload', "auto");

    if (system_type === 'ios') 
    {
        newVideo.onplay = function(e) {
            newVideo.play();
        }
    }

    newVideo.oncanplay = function(evt)
    {
        log("local record play: oncanplay!");            
        var code = 0;
        if (newVideo.error) 
        {
            code = newVideo.error.code;
        }
    }

    newVideo.onended =function(evt)
    {
        log("local record play: onended!");            
        DestoryVideoTag();
    }

    newVideo.onerror = function(evt)
    {
        log("local record play: onerror!");
        //DestoryVideoTag();
    }
    videos.appendChild(newVideo);
}

function CreateVideoTag(id, classname, name, record_url)
{
    var videos = document.getElementById('play_local_record');
    var newVideo = document.createElement("video");
    newVideo.setAttribute("autoplay", "");
    newVideo.setAttribute("id", id);
    newVideo.setAttribute("class", classname);
    newVideo.setAttribute('name', name);
    newVideo.setAttribute('src', record_url);

    if (system_type === 'ios') 
    {
        newVideo.onplay = function(e) {
            newVideo.play();
        }
    }

    newVideo.oncanplay = function(evt)
    {
        log("local record play: oncanplay!");            
        var code = 0;
        if (newVideo.error) 
        {
            code = newVideo.error.code;
        }
    }

    newVideo.onended =function(evt)
    {
        log("local record play: onended!");            
        DestoryVideoTag();
    }

    newVideo.onerror = function(evt)
    {
        log("local record play: onerror!");
        DestoryVideoTag();
    }

    videos.appendChild(newVideo);
}

function DestoryVideoTag()
{
    var videos = document.querySelectorAll('video.play_record_video');
    if(videos)
    {
        for(var i = 0; i < videos.length; i++)
        {
            var obj = videos[i];
            obj.remove();
        }
    }
}

function login() {
    var username = document.getElementById('username').value || 'AnyChat_H5';
    var appid = document.getElementById('appid').value || '';

    username = username + Math.floor(Math.random() * 1000);
    BRAC_LoginEx(username, -1, username, appid, 0, '', '');
    // BRAC_SetSDKOption(BRAC_SO_CLOUD_APPGUID, appid);
    localStorage.appid = appid;
    // BRAC_Login(username, '123', '');
}

function siglogin()
{
    var sigserverurl = document.getElementById('sigserverurl').value || 'http://demo.anychat.cn:8930';
    if(sigserverurl == '' || sigserverurl == null)
    {
        alert('签名服务器url为空！');   
        return;         
    }

    var username = document.getElementById('username').value || 'AnyChat_H5';
    var appid = document.getElementById('appid').value || '';
    if(appid == '' || appid == null)
    {
        alert('appid为空！');   
        return;         
    }

    var parameter = "userid=" + -1 + "&struserid=" + username + "&appid=" + appid;
    $.ajax({
        url: sigserverurl,
        method: 'POST',
        header: {
            'content-type': 'application/x-www-form-urlencoded'
        },
        data: parameter,
        success: function(res)
        {
            log('签名信息请求成功！');
            if (res.errorcode == 0)
            {
                BRAC_LoginEx(username, -1, username, appid, res.timestamp, res.sigStr, '');
            }
        },
        error: function(res)
        {
            alert('签名信息请求失败！');
        }
    })
}

function enterroom() {
    //进房间
    // log('执行进入房间');
    //		BRAC_GetSDKOptionString(BRAC_SO_CLOUD_APPGUID);
    BRAC_GetSDKOptionString(BRAC_SO_CORESDK_BUILDTIME);
    var roomid = document.getElementById('roomid').value || '2018';
    localStorage.anychat_roomid = roomid;
    // BRAC_EnterRoomEx(roomid, '');
    BRAC_EnterRoom(parseInt(roomid), "", 0);
    console.log(BRAC_EnumDevices(BRAC_DEVICE_AUDIOCAPTURE));
    console.log(BRAC_EnumDevices(BRAC_DEVICE_AUDIOCAPTURE));

    isShowStreamRate = true;
    ShowStreamRateInfo();
}

//群聊
function sendtexttoall() 
{
    var text = document.getElementById('sendtext').value;
    if (text) {
        BRAC_SendTextMessage(-1, 0, text);
        log('TextMessage:' + 'textMsg:' + text);
    } else {
        alert('please input text Msg!');
    }
}

//私聊
function sendtextsecret() 
{
    var text = document.getElementById('sendtext').value;
    if (text) {
        var userid = GetSelectOptionValue('select_text_uid');
        if (!userid || (-1 == userid))
        {
            alert('please select userid or do not select selfuid!');
            return false;
        }

        localStorage.anychat_userid = userid;
        BRAC_SendTextMessage(userid, 1, text);
        log('TextMessage:send uid：' + userid + ', textMsg:' + text);
    } else {
        alert('please input text Msg!');
    }
}

//发送传输信息
function sendbuff() {
    var buff = document.getElementById('sendbuff').value;
    if (buff) {
        var userid = GetSelectOptionValue('select_buff_uid');
        if (!userid) {
            alert('please select userid');
            return false;
        }
        localStorage.anychat_userid = userid;
        BRAC_TransBuffer(userid, buff);
        log('TransBuffer:send uid:' + userid + ', buff:' + buff);
    } else {
        alert('please input buff Msg!');
    }
}

function getroomList() {
    log("房间人数：" + BRAC_GetOnlineUser());
}

function leaveroom() {
    isShowStreamRate = false;

    // log('离开房间');
    user_open_id = 0;

    var obj = document.getElementById("select_buff_uid");
    if (obj) 
    {
        for(var i=0;i<obj.options.length;i++) 
        { 
            var userid = obj.options[i].value;
        }
        
        var videochecked = true;
        var audiochecked = true;
        if (audiochecked) 
        {
            BRAC_SetUserStreamInfo(userid, 0, BRAC_STREAMINFO_AUDIOFLAG, 0);                    
        }
            
        if (videochecked) 
        {
            BRAC_SetUserStreamInfo(userid, 0, BRAC_STREAMINFO_VIDEOFLAG, 0);
        }

        if (audiochecked) 
        {
            BRAC_UserSpeakControl(userid, 0);
        }

        if (videochecked) 
        {
            BRAC_UserCameraControlEx(userid, 0, 0, 0, '');
        }             
    }

    DestroySelectUserId();
    BRAC_LeaveRoom();
}

function opencamera_o(isopen) {
    var userid = document.getElementById('userid').value || '-6228';
    localStorage.anychat_userid = userid;
    if (userid) {
        if (isopen == 1) {
            var videochecked = true;
            var audiochecked = true;
            
            InitSelectUserId(userid);

            //先设置音视频开启标志，然后调用摄像头麦克风接口
            //开启音频
            if (audiochecked) 
            {
                BRAC_SetUserStreamInfo(userid, 0, BRAC_STREAMINFO_AUDIOFLAG, 1);               
            }
            //开启视频
            if (videochecked) 
            {
                BRAC_SetUserStreamInfo(userid, 0, BRAC_STREAMINFO_VIDEOFLAG, 1);
            }

            if (audiochecked) 
            {
                BRAC_UserSpeakControl(userid, 1);
            }

            if (videochecked) 
            {
                BRAC_UserCameraControlEx(userid, 1, 0, 0, '');
            }
            
            BRAC_SetVideoPos(userid, document.getElementById('cc'), 'ANYCHAT-VIDEO-REMOTE');
        } else {
            // log('关闭对方摄像头：' + userid);
            BRAC_UserCameraControlEx(userid, 0, 0, 0, '');

            ReleaseSelectUserId(userid);
        }
    }
}

function opencamera_user_id(userid, isopen) {
    var dom = document.getElementById('remote-wrapper'), id;
    if (userid) {
        if (isopen == 1) {
            user_open_id++;
            var videochecked = true;
            var audiochecked = true;
            
            InitSelectUserId(userid);

            //先设置音视频开启标志，然后调用摄像头麦克风接口
            //开启音频
            if (audiochecked) 
            {
                BRAC_SetUserStreamInfo(userid, 0, BRAC_STREAMINFO_AUDIOFLAG, 1);                 
            }
            //开启视频
            if (videochecked) 
            {
                BRAC_SetUserStreamInfo(userid, 0, BRAC_STREAMINFO_VIDEOFLAG, 1);
            }

            if (audiochecked) 
            {
                BRAC_UserSpeakControl(userid, 1);
            }

            if (videochecked) 
            {
                BRAC_UserCameraControlEx(userid, 1, 0, 0, '');
            }

            var Odiv = document.createElement("div");             //创建一个div
            id = Odiv.id = 'video_box' + userid;
            dom.appendChild(Odiv);
            BRAC_SetVideoPos(userid, document.getElementById(id), 'other_video' + userid);
        } else {
            user_open_id--;
            // log('关闭对方摄像头：' + userid);
            BRAC_UserCameraControlEx(userid, 0, 0, 0, '');
            
            ReleaseSelectUserId(userid);
        }
    }
}

//控制自己摄像头
function opencamera(isopen) {
    var mDevices = '';
    var resolution_ratio = [];
    resolution_ratio[0] = {
        width: 320,
        height: 240
    }
    resolution_ratio[1] = {
        width: 640,
        height: 480
    }
    resolution_ratio[2] = {
        width: 1280,
        height: 720
    }
    var ratio_index = $('#resolution_ratio').val();
    var code_rate = $('#code_rate').val() || 300;
    if (isopen == 1) {
        var videochecked = true;
        var audiochecked = true;

        InitSelectUserId(-1);

        // log('打开自己摄像头');
        mDevices = $('#camera').val();
        BRAC_SetUserStreamInfo(-1, 0, BRAC_SO_LOCALVIDEO_DEVICENAME, mDevices);
        BRAC_SetUserStreamInfo(-1, 0, BRAC_SO_LOCALVIDEO_BITRATECTRL, code_rate * 1000); //kbps
        BRAC_SetUserStreamInfo(-1, 0, BRAC_SO_LOCALVIDEO_WIDTHCTRL, 320);
        BRAC_SetUserStreamInfo(-1, 0, BRAC_SO_LOCALVIDEO_HEIGHTCTRL, 240);
        // BRAC_UserCameraControl(-1, 1);

        //先设置音视频开启标志，然后调用摄像头麦克风接口
        //开启音频
        if(audiochecked)
        {
            BRAC_SetUserStreamInfo(-1, 0, BRAC_STREAMINFO_AUDIOFLAG, 1);
        }
        //开启视频
        if(videochecked)
        {
            BRAC_SetUserStreamInfo(-1, 0, BRAC_STREAMINFO_VIDEOFLAG, 1);
        }

        if(audiochecked)
        {
            BRAC_UserSpeakControl(-1, 1);
        }

        if(videochecked)
        {
            BRAC_UserCameraControlEx(-1, 1, 0, 0, '');
        }

        BRAC_SetVideoPos(-1, document.getElementById('local-wrapper'), 'ANYCHAT-VIDEO-LOCAL');
    } else {
        BRAC_UserCameraControlEx(-1, 0, 0, 0, '');

        ReleaseSelectUserId(-1);
    }
}

$('#camera').change(function () {
    var mDevices = $(this).val();
    BRAC_SelectVideoCapture(1, mDevices);
});

$('#code_rate').change(function () {
    var c = $(this).val();
    BRAC_SetUserStreamInfo(-1, 0, BRAC_SO_LOCALVIDEO_BITRATECTRL, c - 0); //kbps
});

setTimeout(function () {
    //video
    var mDevices = BRAC_EnumDevices(1);
    var html = '';
    for (var i in mDevices) {
        html += '<option value="' + mDevices[i] + '">' + mDevices[i] + '</option>';
    }
    //document.getElementById('camera').innerHTML = html;


    //audio
    mDevices = BRAC_EnumDevices(2);
    html = '';
    for (var i in mDevices) {
        html += '<option value="' + mDevices[i] + '">' + mDevices[i] + '</option>';
    }
    //document.getElementById('audio').innerHTML = html;
}, 1000);

//注销
function layout() {
    isShowStreamRate = false;
    DestroySelectUserId();

    user_open_id = 0;
    BRAC_Logout();
}

function getPar(par) {
    //获取当前URL
    var local_url = document.location.href;
    //获取要取得的get参数位置
    var get = local_url.indexOf(par + "=");
    if (get == -1) {
        return false;
    }
    //截取字符串
    var get_par = local_url.slice(par.length + get + 1);
    //判断截取后的字符串是否还有其他get参数
    var nextPar = get_par.indexOf("&");
    if (nextPar != -1) {
        get_par = get_par.slice(0, nextPar);
    }
    return get_par;
}

//初始化本地对象信息
function InitClientObjectInfo(mSelfUserId, dwAgentFlags, dwPriority) {
    log('同步');
    //初始化服务区域Id数组
    areaArrayIdx = 0;
    areaIdArray = [];
    //业务对象身份初始化
    BRAC_SetSDKOption(BRAC_SO_OBJECT_INITFLAGS, dwAgentFlags);
    //客户端用户对象优先级
    BRAC_ObjectSetValue(ANYCHAT_OBJECT_TYPE_CLIENTUSER, mSelfUserId, ANYCHAT_OBJECT_INFO_PRIORITY, dwPriority);
    var dwAttribute = -1;
    BRAC_ObjectSetValue(ANYCHAT_OBJECT_TYPE_CLIENTUSER, mSelfUserId, ANYCHAT_OBJECT_INFO_ATTRIBUTE, dwAttribute);
    //向服务器发送数据同步请求指令
    BRAC_ObjectControl(ANYCHAT_OBJECT_TYPE_AREA, ANYCHAT_INVALID_OBJECT_ID, ANYCHAT_OBJECT_CTRL_SYNCDATA, mSelfUserId, 0, 0, 0, "");
}

/**
 * 营业厅
 */
//服务区域(营业厅)ID数组
var areaIdArray = null;
var areaArrayIdx = 0;

//显示服务区域(营业厅)
function showSerivceArea() {
    // var areaName = "";
    // var description = "";

    // setTimeout(function () {
    // 	var html = '';
    // 	for (var idx in areaIdArray) {
    // 		areaName = BRAC_ObjectGetStringValue(ANYCHAT_OBJECT_TYPE_AREA, areaIdArray[idx], ANYCHAT_OBJECT_INFO_NAME);
    // 		description = BRAC_ObjectGetStringValue(ANYCHAT_OBJECT_TYPE_AREA, areaIdArray[idx], ANYCHAT_OBJECT_INFO_DESCRIPTION);
    // 		html += '<option value="' + areaIdArray[idx] + '">' + areaName + '</option>';

    // 	}

    // 	document.getElementById('area').innerHTML = html;
    // }, 600);

}

function enterArea(is) {
    var dwAgentFlags = 0;
    InitClientObjectInfo(-1, dwAgentFlags, 5);
    var val = parseInt(document.getElementById('areaid').value);
    if (is) {
        log('执行进入营业厅：' + val);
        BRAC_ObjectControl(ANYCHAT_OBJECT_TYPE_AREA, val, ANYCHAT_AREA_CTRL_USERENTER, 0, 0, 0, 0, "");
    } else {
        log('退出营业厅');
        BRAC_ObjectControl(ANYCHAT_OBJECT_TYPE_AREA, val, ANYCHAT_AREA_CTRL_USERLEAVE, 0, 0, 0, 0, "");
    }

}

function areaEnter() 
{
    setTimeout(function () {
        var queueList = BRAC_ObjectGetIdList(ANYCHAT_OBJECT_TYPE_QUEUE);
        var html = '';
        for (var i in queueList) {
            var queueListId = parseInt(queueList[i]);
            /**获取队列名称*/
            var queueName = BRAC_ObjectGetStringValue(ANYCHAT_OBJECT_TYPE_QUEUE, queueListId, ANYCHAT_OBJECT_INFO_NAME);
            /**获取队列排队人数*/
            var queueLength = BRAC_ObjectGetIntValue(ANYCHAT_OBJECT_TYPE_QUEUE, queueListId, ANYCHAT_QUEUE_INFO_LENGTH);
            queueLength = queueLength < 0 ? 0 : queueLength;
            /**获取队列信息*/
            var queueInfo = BRAC_ObjectGetStringValue(ANYCHAT_OBJECT_TYPE_QUEUE, queueListId, ANYCHAT_OBJECT_INFO_DESCRIPTION);
            var attributeValue = BRAC_ObjectGetIntValue(ANYCHAT_OBJECT_TYPE_QUEUE, queueListId, ANYCHAT_OBJECT_INFO_ATTRIBUTE);

            var queueSkillName = "";
            html += '<option value="' + queueList[i] + '">' + queueName + '</option>';
            log('队列名称：' + queueName);
        }
        document.getElementById('queue').innerHTML = html;
    }, 600);

}

var queueId = 0;

function enterQueue(is) 
{
    var val = parseInt(document.getElementById('queueid').value);
    if (is) {
        queueId = val;
        log('执行进入队列排队：' + val);
        var beforeUserNum = BRAC_ObjectGetIntValue(ANYCHAT_OBJECT_TYPE_QUEUE, val, ANYCHAT_QUEUE_INFO_BEFOREUSERNUM);
        beforeUserNum = beforeUserNum < 0 ? 0 : beforeUserNum;
        beforeUserNum++;
        log('排在我前面有' + beforeUserNum + '人');
        BRAC_ObjectControl(ANYCHAT_OBJECT_TYPE_QUEUE, val, ANYCHAT_QUEUE_CTRL_USERENTER, 0, 0, 0, 0, "");
    } else {
        log('退出队列');
        queueId = 0;
        BRAC_ObjectControl(ANYCHAT_OBJECT_TYPE_QUEUE, val, ANYCHAT_QUEUE_CTRL_USERLEAVE, 0, 0, 0, 0, "");
    }
}

//呼叫
function callOther() {
    var val = parseInt(document.getElementById('calluserid').value);
    BRAC_VideoCallControl(BRAC_VIDEOCALL_EVENT_REQUEST, val, 0, 0, 0, "");
}
var mTargetUserId;

function onVideoCallControlRequest(dwUserId, dwErrorCode, dwFlags, dwParam, szUserStr) {
    mTargetUserId = dwUserId;
    $('#callmodal').modal('show');
}

//同意呼叫
function agree_call() {
    BRAC_VideoCallControl(BRAC_VIDEOCALL_EVENT_REPLY, mTargetUserId, 0, 0, 0, "");
    $('#callmodal').modal('hide');
}

//拒绝呼叫
function cancel_call() {
    BRAC_VideoCallControl(BRAC_VIDEOCALL_EVENT_REPLY, mTargetUserId, GV_ERR_SESSION_REFUSE, 0, 0, "");
    $('#callmodal').modal('hide');
}

//通话开始
var isCall = false;

function onVideoCallControlStart(dwUserId, dwErrorCode, dwFlags, dwParam, szUserStr) {
    //请求进入指定的房间
    $('#callmodal').modal('hide');
    BRAC_EnterRoom(dwParam, "", 0);
    isCall = true;
}

//呼叫打开
function is_open_other() {
    if (isCall) {
        // log('打开自己摄像头');
        // var mDevices = BRAC_EnumDevices(BRAC_DEVICE_VIDEOCAPTURE);
        var mDevices = '';
        var resolution_ratio = [];
        resolution_ratio[0] = {
            width: 320,
            height: 240
        }
        resolution_ratio[1] = {
            width: 640,
            height: 480
        }
        mDevices = $('#camera').val();
        var ratio_index = $('#resolution_ratio').val();
        var code_rate = $('#code_rate').val() || 300;
        BRAC_SetUserStreamInfo(-1, 0, BRAC_SO_LOCALVIDEO_DEVICENAME, mDevices);
        BRAC_SetUserStreamInfo(-1, 0, BRAC_SO_LOCALVIDEO_BITRATECTRL, code_rate * 1000); //kbps
        BRAC_SetUserStreamInfo(-1, 0, BRAC_SO_LOCALVIDEO_WIDTHCTRL, 320);
        BRAC_SetUserStreamInfo(-1, 0, BRAC_SO_LOCALVIDEO_HEIGHTCTRL, 240);
      
        //开启音频
        BRAC_SetUserStreamInfo(-1, 0, BRAC_STREAMINFO_AUDIOFLAG, 1);
        //开启视频
        BRAC_SetUserStreamInfo(-1, 0, BRAC_STREAMINFO_VIDEOFLAG, 1);

        BRAC_UserSpeakControl(-1, 1);
        BRAC_UserCameraControlEx(-1, 1, 0, 0, '');
        BRAC_SetVideoPos(-1, document.getElementById('local-wrapper'), 'ANYCHAT-VIDEO-LOCAL');

        setTimeout(function () {
            // log('打开对方摄像头：' + mTargetUserId);
            BRAC_UserSpeakControl(mTargetUserId, 1);
            BRAC_UserCameraControlEx(mTargetUserId, 1, 0, 0, '');
            BRAC_SetVideoPos(mTargetUserId, document.getElementById('cc'), 'ANYCHAT-VIDEO-REMOTE');
        }, 1000);
    }
}

//视频通话结束
function onVideoCallControlFinish(dwUserId, dwErrorCode, dwFlags, dwParam, szUserStr) {
    BRAC_LeaveRoom(-1);
    mTargetUserId = 0;
}

//呼叫坐席
function callAgent(agentId) {
    mTargetUserId = agentId;
    BRAC_VideoCallControl(BRAC_VIDEOCALL_EVENT_REQUEST, agentId, 0, 0, 0, "");
}
// 13424041669
// 18819458342 huang

var timer;

function queuetime(is) {
    var second = 0;
    var TimeFormat = function (time) {
        var m = Math.floor(time / 60);
        m = m > 9 ? m : (m > 0 ? "0" + m : "00");
        var s = time % 60;
        s = s > 9 ? s : (s > 0 ? "0" + s : "00");
        return m + ":" + s;
    };
    if (is) {
        clearInterval(timer);
        $('#queueview').modal('hide');
        document.getElementById('time').innerHTML = '';
    } else {
        $('#queueview').modal('show');
        clearInterval(timer);
        timer = setInterval(function () {
            second++;
            var time = TimeFormat(second);
            var beforeUserNum = BRAC_ObjectGetIntValue(ANYCHAT_OBJECT_TYPE_QUEUE, queueId, ANYCHAT_QUEUE_INFO_BEFOREUSERNUM);
            beforeUserNum = beforeUserNum < 0 ? 0 : beforeUserNum;
            beforeUserNum++;
            document.getElementById('qlength').innerHTML = '我前面有' + beforeUserNum + '人在排队';
            document.getElementById('time').innerHTML = '正在排队' + time;
        }, 1000);
    }
}

function onTextMessage(msg)
{
    document.getElementById('sendtext').value = msg;
}

function onTransMessage(msg)
{
    document.getElementById('sendbuff').value = msg;
}

function onShowSnapShot(urlFile)
{
    $('#pictu').attr('src', urlFile);
}

function InitSelectUserId(userid)
{
    AddSelectOption('select_reset_uid', userid);
    AddSelectOption('select_text_uid', userid);
    AddSelectOption('select_buff_uid', userid);
    AddSelectOption('select_shot_uid', userid);
    AddSelectOption('select_record_uid', userid);   
}

function ReleaseSelectUserId(userid)
{
    DelSelectOption('select_reset_uid', userid);
    DelSelectOption('select_text_uid', userid);
    DelSelectOption('select_buff_uid', userid);
    DelSelectOption('select_shot_uid', userid);
    DelSelectOption('select_record_uid', userid);
}

function DestroySelectUserId()
{
    CleanSelectOption('select_reset_uid');
    CleanSelectOption('select_text_uid');
    CleanSelectOption('select_buff_uid');
    CleanSelectOption('select_shot_uid');
    CleanSelectOption('select_record_uid');
}

function GetSelectOptionValue(id)
{
    var obj = document.getElementById(id);
    if (obj) 
    {
        if (obj.options.length > 0) 
        {
            return obj.options[obj.selectedIndex].value;            
        }
        else
        {
            return 0;
        }
    }
}

function AddSelectOption(id, value)
{
    var obj = document.getElementById(id);
    if (obj) 
    {
        obj.options.add(new Option(value, value));            
    }
}

function DelSelectOption(id, value)
{
    var obj = document.getElementById(id);
    if (obj) 
    {
        for (var index = 0; index < obj.options.length; index++) 
        {
            if (obj.options[index].value == value) 
            {
                obj.options.remove(index);
                break;
            }   
        }
    }
}

function CleanSelectOption(id)
{
    var obj = document.getElementById(id);
    if (obj) 
    {
        obj.options.length = 0;
    }
}

function ShowStreamRateInfo()
{
    var uploadAudioRate = 0;
    var uploadVideoRate = 0;
    var downloadAudioRate = 0;
    var downloadVideoRate = 0;
    var getRateTimer = setInterval(function(){
        if(!isShowStreamRate)
        {
            $("#uploadRate").html(0);
            $("#downloadRate").html(0);
            clearInterval(getRateTimer);
            return;
        }

        var obj = document.getElementById("select_buff_uid");
        if (obj) 
        {
            for (var index = 0; index < obj.options.length; index++) 
            {
                if(-1 == obj.options[index].value)
                {
                    uploadAudioRate = BRAC_QueryUserStateInt(-1, BRAC_USERSTATE_AUDIOBITRATE);
                    uploadVideoRate = BRAC_QueryUserStateInt(-1, BRAC_USERSTATE_VIDEOBITRATE);
                }
                else
                {
                    downloadAudioRate +=  BRAC_QueryUserStateInt(obj.options[index].value, BRAC_USERSTATE_AUDIOBITRATE);
                    downloadVideoRate +=  BRAC_QueryUserStateInt(obj.options[index].value, BRAC_USERSTATE_VIDEOBITRATE);
                }
            }

            $("#uploadRate").html(uploadAudioRate+uploadVideoRate);
            $("#downloadRate").html(downloadAudioRate+downloadVideoRate);
            uploadAudioRate = 0;
            uploadVideoRate = 0;
            downloadAudioRate = 0;
            downloadVideoRate = 0;
        }
    }, 1000) 
}

// function ResetDc() {
//     ResetChnlFun(-1, 0, 1);
// }

// function ResetPc() {
//     var userid = GetSelectOptionValue('select_reset_uid');
//     ResetChnlFun(userid, 0, 0);
// }

//导出日志
function exlogtxt() {
    function is_weixn() {
        var ua = navigator.userAgent.toLowerCase();
        if (ua.match(/MicroMessenger/i) == "micromessenger") {
            return true;
        } else {
            return false;
        }
    }
    if (is_weixn()) {
        var url = log_obj.doExplore(true);
        $('#img_').attr('src', url);
        $('#log_id').modal('show');

    } else {
        log_obj.doExplore(false);
    }
}