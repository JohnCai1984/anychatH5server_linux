export LD_LIBRARY_PATH=$PRO_PATH:$LD_LIBRARY_PATH && ./anychatwebrtcgwserver -d

